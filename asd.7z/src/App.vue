<template>
  <!-- <HomeView/> -->
  <div class="wrap">
    <div class="container">
      <RouterView />
    </div>
  </div>
</template>

<script>
  import {
    // ref,
    // computed
  } from 'vue'
  // import axios from 'axios'
  // import {fetchAllApi} from './api/index' ㅁㅁㅁㅁㅁㅁㅁㅁㅁㅁㅁㅁㅁ
  import {
    useStore
  } from 'vuex'
  // import HomeView from './views/HomeView.vue'

  export default {
    components: {
      // HomeView
      
    },
    setup() {
      // const data = ref([]);

      //vuex에 dispatch 전송 ㅁㅁㅁㅁㅁㅁㅁㅁㅁㅁ

      /*
      // axios.get('https://ghibliapi.herokuapp.com/films')
      fetchAllApi()
      .then(response => {
        data.value = response.data
      })
      .catch(err => console.log(err))
      */ //ㅁㅁㅁㅁㅁㅁㅁㅁㅁㅁㅁㅁㅁㅁㅁ

      const store = useStore();
      store.dispatch('fetchMovieList')
      // const data = computed(() => store.getters.getMovieList); HomeVIew로 보냄
      return {
        // data
      }
    }
  }
</script>

<style>
  * {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
  }

  ul,
  li {
    list-style: none;
  }

  a {
    text-decoration: none;
    color: #333;
  }

  html {
    font-size: 16px;
    background-color: aliceblue;
  }

  .wrap {
    position: relative;
    display: block;
  }

  .container {
    position: relative;
    display: flex;
    flex-wrap: wrap;
    justify-content: space-around;
  }
</style>