<template>
  <div v-for="(item, index) in movieList" :key="index" class="movie">

    <!-- <img :src="item.image"/>
  <h2>{{item.title}} <small>{{item.original_title}}</small></h2>
  <p>
    {{item.description}}
  </p> -->
    <!-- <MovieList :item = "item" /> 헷갈릴까봐 적어둠-->
    <MovieList :propsdata="item" />

  </div>
</template>

<script>
  import {
    useStore
  } from 'vuex'
  import {
    computed
  } from 'vue'
  import MovieList from '../components/movieList.vue'

  export default {
    // props : ['aaa'],
    components: {
      MovieList
    },
    setup() {
      const store = useStore();
      // const data = computed(()=> store.getters.getMovieList);
      const movieList = computed(() => store.getters.getMovieList);
      return {
        // data,
        movieList
      }
    }
  }
</script>

<style scoped>
  .movie {
    position: relative;
    display: block;
    width: 49%;
    background: #fff;
    margin-bottom: 70px;
    border-radius: 5px;
    color: #adadb9;
    padding: 20px;
    box-shadow: 0 13px 27px -5px rgba(50, 50, 93, 0.25),
      0 8px 16px -8px rgba(0, 0, 0, 0.3), 0 -6px 16px -6px rgba(0, 0, 0, 0.025);
    cursor: pointer;
  }
  @media screen and (max-width: 1000px){
    .movie {
      width: 95%;
    }    
  }
</style>