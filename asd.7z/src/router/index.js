import { createRouter, createWebHistory } from "vue-router";
import HomeView from '../views/HomeView'
import DetailView from '../views/DetailView'

const router = createRouter({
  history : createWebHistory(),
  routes : [
    {
      //웹브라우져 주소 표시줄에 명시
      path : '/',
      //RouterView에 보여줄 페이지 컨포넌트명
      redirect: '/home'
    },
    {
      //웹브라우져 주소 표시줄에 명시
      path : '/home',
      //RouterView에 보여줄 페이지 컨포넌트명
      component: HomeView
    },
    {
      path: '/detail/:id',
      component: DetailView
    }
  ]
});

export default router;